#ifndef __ROBOMASTER_VCAN_H
#define __ROBOMASTER_VCAN_H
extern short wave_form_data[6];
void shanwai_send_wave_form(void);
#endif



